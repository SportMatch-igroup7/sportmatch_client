import React, { Component } from 'react'

export default class CompaniesUpdate extends Component {
    render() {
        return (
            <div>
                <iframe width="1140" height="541.25" src="https://app.powerbi.com/reportEmbed?reportId=b0d8dfd1-bc06-4870-b8f8-93c92234fd43&autoAuth=true&ctid=d8175ea1-6cdb-4546-b134-fb869b03311f&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXdlc3QtZXVyb3BlLXJlZGlyZWN0LmFuYWx5c2lzLndpbmRvd3MubmV0LyJ9" frameborder="0" allowFullScreen="true"></iframe>
            </div>
        )
    }
}
