import React, { Component } from 'react'

export default class QualsUpdate extends Component {
    render() {
        return (
            <div>
                <iframe width="100%" height="541.25" src="http://proj.ruppin.ac.il/igroup7/proj/pages/managQualification.html" frameborder="0" allowFullScreen="true"></iframe>
            </div>
        )
    }
}
