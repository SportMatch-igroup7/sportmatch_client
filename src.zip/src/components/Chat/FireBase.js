const firebaseConfig = {
    apiKey: "AIzaSyBBiRnc3hQAT5pBL20m3Bq6RHkp6Kh3bZ0",
    authDomain: "sportmatch-b4d86.firebaseapp.com",
    databaseURL: "https://sportmatch-b4d86.firebaseio.com",
    projectId: "sportmatch-b4d86",
    storageBucket: "sportmatch-b4d86.appspot.com",
    messagingSenderId: "446043012870",
    appId: "1:446043012870:web:4688eedef38cc84f42e887",
    measurementId: "G-3RTXPD9NDJ"
  };

  export default firebaseConfig;