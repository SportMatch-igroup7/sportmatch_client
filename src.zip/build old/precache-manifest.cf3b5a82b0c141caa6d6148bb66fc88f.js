self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bfc7727db4dc62d75c545e0737d7d469",
    "url": "./index.html"
  },
  {
    "revision": "92211ff54c1f4062724e",
    "url": "./static/css/2.f139a539.chunk.css"
  },
  {
    "revision": "7a93ba24415c428e4039",
    "url": "./static/css/main.7b148310.chunk.css"
  },
  {
    "revision": "92211ff54c1f4062724e",
    "url": "./static/js/2.bd13566a.chunk.js"
  },
  {
    "revision": "662ba31961d66932b4dcec6076723836",
    "url": "./static/js/2.bd13566a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7a93ba24415c428e4039",
    "url": "./static/js/main.13b47b2d.chunk.js"
  },
  {
    "revision": "14a1f503700dcc562e63",
    "url": "./static/js/runtime-main.59139fef.js"
  }
]);